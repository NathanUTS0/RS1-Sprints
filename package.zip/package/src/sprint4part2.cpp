/**
 * @file slo3_5_solution.cpp
 * @brief Node for detecting cylinders in laser scan data, displaying results on ground truth, and planning navigation with Nav2.
 */

#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/laser_scan.hpp>
#include <gazebo_msgs/srv/spawn_entity.hpp>
#include <nav2_msgs/action/navigate_to_pose.hpp>
#include <rclcpp_action/rclcpp_action.hpp>
#include <tf2_ros/transform_listener.h>
#include <tf2_ros/buffer.h>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.hpp>  
#include <geometry_msgs/msg/transform_stamped.hpp>
#include <opencv2/opencv.hpp>
#include <cmath>
#include <vector>
#include <optional>

class CylinderDetectionNode : public rclcpp::Node
{
public:
    using NavigateToPose = nav2_msgs::action::NavigateToPose;
    using GoalHandleNav = rclcpp_action::ClientGoalHandle<NavigateToPose>;

    CylinderDetectionNode() : Node("cylinder_detection_node")
    {
        // Load and process ground truth map
        ground_truth_map_ = cv::imread("/home/student/ros2_ws/src/package/src/ground_truth_map.pgm", cv::IMREAD_GRAYSCALE);
        if (ground_truth_map_.empty())
        {
            RCLCPP_ERROR(this->get_logger(), "Could not load the ground truth map.");
            rclcpp::shutdown();
            return;
        }
        cv::threshold(ground_truth_map_, binary_map_, 200, 255, cv::THRESH_BINARY_INV);
        std::vector<std::vector<cv::Point>> contours;
        cv::findContours(binary_map_, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
        room_roi_ = cv::boundingRect(contours[0]);
        for (size_t i = 1; i < contours.size(); i++) {
            room_roi_ = room_roi_ | cv::boundingRect(contours[i]);
        }
        ground_truth_map_cropped_ = ground_truth_map_(room_roi_).clone();
        cv::cvtColor(ground_truth_map_cropped_, ground_truth_map_cropped_, cv::COLOR_GRAY2BGR);

        // Initialize maps and visualization
        laser_scan_map_ = cv::Mat::zeros(ground_truth_map_cropped_.size(), CV_8UC3);
        laser_scan_edges_map_ = cv::Mat::zeros(ground_truth_map_cropped_.size(), CV_8UC1);
        cv::imshow("Ground Truth Map", ground_truth_map_cropped_);
        cv::imshow("Laser Scan Map", laser_scan_map_);
        cv::imshow("Edge Detection Map", laser_scan_edges_map_);
        cv::waitKey(100);

        map_resolution_ = 0.05; 
        map_origin_ = {-8, -10.6}; 
        

        // Initialize TF listener and Nav2 client
        tf_buffer_ = std::make_shared<tf2_ros::Buffer>(this->get_clock());
        tf_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);
        nav2_client_ = rclcpp_action::create_client<NavigateToPose>(this, "navigate_to_pose");

        // Set goal  using Nav2
        set_goal(1.0, 3.0);
        
        spawn_cylinder(1, 2.5); 

        // Subscribe to LaserScan for cylinder detection
        laser_sub_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
            "/scan", 10, std::bind(&CylinderDetectionNode::laser_callback, this, std::placeholders::_1));

        mapping_cylinder_ = false;
        waypoint_index_ = 0;

        // Visualization loop to display maps and path
        rclcpp::Rate rate(15);
        while (rclcpp::ok()) {
            cv::imshow("Ground Truth Map", ground_truth_map_cropped_);
            cv::imshow("Laser Scan Map", laser_scan_map_);
            cv::imshow("Edge Detection Map", laser_scan_edges_map_);
            if (cv::waitKey(1) == 27) {
                break;
            }
            rclcpp::spin_some(this->get_node_base_interface());
            rate.sleep();
        }
    }

private:
    cv::Mat ground_truth_map_, ground_truth_map_cropped_, binary_map_, laser_scan_map_, laser_scan_edges_map_;
    rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr laser_sub_;
    rclcpp_action::Client<NavigateToPose>::SharedPtr nav2_client_;
    std::shared_ptr<tf2_ros::Buffer> tf_buffer_;
    std::shared_ptr<tf2_ros::TransformListener> tf_listener_;
    double map_resolution_;
    std::pair<double, double> map_origin_;
    cv::Rect room_roi_;
    std::vector<std::pair<int, int>> detected_cylinders_;  // Stores previously detected cylinder locations
    bool mapping_cylinder_ = false;
    geometry_msgs::msg::Pose deviation_return_pose_;
    std::vector<geometry_msgs::msg::Pose> waypoints_;
    size_t waypoint_index_ = 0;
    bool deviation_reached_;
    bool PointB = false;
    geometry_msgs::msg::Pose final_goal_pose_;

   void laser_callback(const sensor_msgs::msg::LaserScan::SharedPtr msg)
{
    laser_scan_map_ = cv::Mat::zeros(ground_truth_map_cropped_.size(), CV_8UC3);
    laser_scan_edges_map_ = cv::Mat::zeros(ground_truth_map_cropped_.size(), CV_8UC1);

    try {
        // Transform the TurtleBot's current position in the "map" frame
       geometry_msgs::msg::TransformStamped transform_stamped = tf_buffer_->lookupTransform("map", msg->header.frame_id, rclcpp::Time(0));
        transform_stamped = tf_buffer_->lookupTransform("map", "base_link", tf2::TimePointZero);

        // Calculate pixel coordinates of TurtleBot's position
        int bot_pixel_x = static_cast<int>((transform_stamped.transform.translation.x - map_origin_.first) / map_resolution_) - room_roi_.x;
        int bot_pixel_y = static_cast<int>((-transform_stamped.transform.translation.y - map_origin_.second) / map_resolution_) - room_roi_.y;

         cv::Scalar color = mapping_cylinder_ ? cv::Scalar(255, 0, 0) : cv::Scalar(0, 255, 0);
            if (bot_pixel_x >= 0 && bot_pixel_x < ground_truth_map_cropped_.cols && bot_pixel_y >= 0 && bot_pixel_y < ground_truth_map_cropped_.rows) {
                cv::circle(ground_truth_map_cropped_, cv::Point(bot_pixel_x, bot_pixel_y), 2, color, -1);
            }

        // Extract yaw from the quaternion
        tf2::Quaternion q(
            transform_stamped.transform.rotation.x,
            transform_stamped.transform.rotation.y,
            transform_stamped.transform.rotation.z,
            transform_stamped.transform.rotation.w);
        double roll, pitch, yaw;
        tf2::Matrix3x3(q).getRPY(roll, pitch, yaw);

        // Process LaserScan data for cylinder detection
        float angle = msg->angle_min;
        for (size_t i = 0; i < msg->ranges.size(); ++i) {
            float range = msg->ranges[i];
            if (range > msg->range_min && range < msg->range_max) {
                float x = range * cos(angle);
                float y = range * sin(angle);

                // Convert LaserScan point to map coordinates
                float map_x = transform_stamped.transform.translation.x + (x * cos(yaw) - y * sin(yaw));
                float map_y = transform_stamped.transform.translation.y + (x * sin(yaw) + y * cos(yaw));

                int pixel_x = static_cast<int>((map_x - map_origin_.first) / map_resolution_) - room_roi_.x;
                int pixel_y = static_cast<int>((-map_y - map_origin_.second) / map_resolution_) - room_roi_.y;

                // Plot laser points on the laser scan map and edge detection map
                if (pixel_x >= 0 && pixel_x < laser_scan_map_.cols && pixel_y >= 0 && pixel_y < laser_scan_map_.rows) {
                    cv::circle(laser_scan_map_, cv::Point(pixel_x, pixel_y), 1, cv::Scalar(255, 255, 255), -1);
                    laser_scan_edges_map_.at<uchar>(pixel_y, pixel_x) = 255;

                    // Check and mark the cylinder on the ground truth map
                    if (!is_known_ground_truth(pixel_x, pixel_y) && is_cylinder_shape(pixel_x, pixel_y)) {
                        if (!is_cylinder_already_marked(pixel_x, pixel_y)) {
                            mapping_cylinder_ = true;
                            deviation_return_pose_.position.x = transform_stamped.transform.translation.x;
                            deviation_return_pose_.position.y = transform_stamped.transform.translation.y;
                            deviation_return_pose_.position.z = transform_stamped.transform.translation.z;
                            deviation_return_pose_.orientation = transform_stamped.transform.rotation;

                            draw_cylinder_marker(pixel_x, pixel_y);
                            detected_cylinders_.emplace_back(pixel_x, pixel_y);
                            RCLCPP_INFO(this->get_logger(), "New cylinder marked at (%d, %d)", pixel_x, pixel_y);
                            generate_waypoints_around_cylinder(map_x, map_y, yaw);
                        }
                    }
                }
            }
            angle += msg->angle_increment;
        }

        // Apply Gaussian blur and edge detection on the laser scan map
        cv::GaussianBlur(laser_scan_edges_map_, laser_scan_edges_map_, cv::Size(5, 5), 0);
        cv::Canny(laser_scan_edges_map_, laser_scan_edges_map_, 30, 100);

        // Display updated maps
        cv::imshow("Ground Truth Map", ground_truth_map_cropped_);
        cv::imshow("Laser Scan Map", laser_scan_map_);
        cv::imshow("Edge Detection Map", laser_scan_edges_map_);
        cv::waitKey(1);
    }
    catch (tf2::TransformException &ex) {
        RCLCPP_WARN(this->get_logger(), "Could not transform: %s", ex.what());
    }
}

  void set_goal(double goal_x, double goal_y, double threshold = 0.4)
{
    if (!nav2_client_->wait_for_action_server(std::chrono::seconds(5))) {
        RCLCPP_ERROR(this->get_logger(), "Nav2 action server not available.");
        return;
    }

    if (!mapping_cylinder_ && !deviation_reached_) {
        final_goal_pose_.position.x = goal_x;
        final_goal_pose_.position.y = goal_y;
        final_goal_pose_.orientation.w = 1.0;
    }

RCLCPP_INFO(this->get_logger(), "Navigating to goal at: (%.2f, %.2f)", goal_x, goal_y);
if (PointB == false){
    mark_goal_on_map(goal_x, goal_y);
    PointB = true;
}

    auto goal_msg = NavigateToPose::Goal();
    goal_msg.pose.header.frame_id = "map";
    goal_msg.pose.header.stamp = this->now();
    goal_msg.pose.pose.position.x = goal_x;
    goal_msg.pose.pose.position.y = goal_y;
    goal_msg.pose.pose.orientation.w = 1.0;

    auto send_goal_options = rclcpp_action::Client<NavigateToPose>::SendGoalOptions();

    send_goal_options.goal_response_callback = 
        [this](GoalHandleNav::SharedPtr goal_handle) {
            if (!goal_handle) 
                RCLCPP_ERROR(this->get_logger(), "Goal was rejected by server.");
            else 
                RCLCPP_INFO(this->get_logger(), "Goal accepted by server.");
        };

    send_goal_options.result_callback = [this, goal_x, goal_y, threshold](const GoalHandleNav::WrappedResult &result) {
        if (result.code == rclcpp_action::ResultCode::SUCCEEDED) {
            RCLCPP_INFO(this->get_logger(), "Goal reached.");

            // Check if the TurtleBot is back at the deviation point
            if (std::hypot(deviation_return_pose_.position.x - goal_x, deviation_return_pose_.position.y - goal_y) < threshold) {
                deviation_reached_ = true;  // TurtleBot has reached the deviation point
                mapping_cylinder_ = false; 
                 set_goal(final_goal_pose_.position.x, final_goal_pose_.position.y);
            }
            
            if (mapping_cylinder_ && !deviation_reached_) {
                // If still navigating around the cylinder or returning to deviation point
                execute_waypoint_navigation();
            }
        } else {
            RCLCPP_WARN(this->get_logger(), "Goal failed.");
        }
    };

    nav2_client_->async_send_goal(goal_msg, send_goal_options);
}

    bool is_cylinder_shape(int pixel_x, int pixel_y)
    {
        std::vector<std::vector<cv::Point>> contours;
        cv::findContours(laser_scan_edges_map_, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

        double target_width_meters = 0.3;  // 30 cm
        double margin_of_error = 0.1;      // 10 cm margin

        for (const auto &contour : contours)
        {
            cv::Rect bounding_box = cv::boundingRect(contour);
            double width_in_meters = bounding_box.width * map_resolution_;

            if (width_in_meters >= (target_width_meters - margin_of_error) && 
                width_in_meters <= (target_width_meters + margin_of_error))
            {
                return true;
            }
        }
        return false;
    }
    
    bool is_cylinder_concave_shape(int pixel_x, int pixel_y)
    {
        RCLCPP_INFO(this->get_logger(), "Starting concave shape detection at (%d, %d)", pixel_x, pixel_y);

        std::vector<std::vector<cv::Point>> contours;
        cv::findContours(laser_scan_edges_map_, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

        for (const auto &contour : contours)
        {
            cv::Rect bounding_box = cv::boundingRect(contour);
            if (std::abs(bounding_box.x - pixel_x) < 20 && std::abs(bounding_box.y - pixel_y) < 20) // Proximity check
            {
                double area = cv::contourArea(contour);
                double perimeter = cv::arcLength(contour, true);
                double circularity = (perimeter == 0) ? 0 : 4 * M_PI * area / (perimeter * perimeter);

                RCLCPP_INFO(this->get_logger(), "Contour circularity at (%d, %d): %.2f", pixel_x, pixel_y, circularity);

                // Check if circularity falls within the desired range for a concave cylinder
                if (circularity > 0.7 && circularity < 1.2)
                {
                    RCLCPP_INFO(this->get_logger(), "Concave cylinder shape detected at (%d, %d)", pixel_x, pixel_y);
                    return true;
                }
                else
                {
                    RCLCPP_INFO(this->get_logger(), "Contour circularity out of range for concave cylinder.");
                }
            }
        }
        RCLCPP_INFO(this->get_logger(), "No concave cylinder shape detected at (%d, %d)", pixel_x, pixel_y);
        return false;
    }

    bool is_cylinder_already_marked(int pixel_x, int pixel_y, double tolerance = 20.0)
    {
        for (const auto& position : detected_cylinders_)
        {
            double distance = std::hypot(position.first - pixel_x, position.second - pixel_y);
            if (distance < tolerance)
            {
                return true;
            }
        }
        return false;
    }

 bool is_known_ground_truth(int pixel_x, int pixel_y)
{
    int radius = 20;                 // Search radius in pixels
    int color_threshold = 30;         // Threshold for proximity to black (0, 0, 0)

    for (int dy = -radius; dy <= radius; ++dy)
    {
        for (int dx = -radius; dx <= radius; ++dx)
        {
            int nx = pixel_x + dx;
            int ny = pixel_y + dy;
            if (nx >= 0 && nx < ground_truth_map_cropped_.cols && ny >= 0 && ny < ground_truth_map_cropped_.rows)
            {
                cv::Vec3b color = ground_truth_map_cropped_.at<cv::Vec3b>(ny, nx);

                // Check if color is close to black within the threshold range
                if (color[0] <= color_threshold && color[1] <= color_threshold && color[2] <= color_threshold)
                {
                    return true;
                }
            }
        }
    }
    return false;
}

    void draw_cylinder_marker(int pixel_x, int pixel_y)
    {
        cv::circle(laser_scan_map_, cv::Point(pixel_x, pixel_y), 5, cv::Scalar(0, 0, 255), -1);
        cv::circle(ground_truth_map_cropped_, cv::Point(pixel_x, pixel_y), 5, cv::Scalar(0, 0, 255), -1);
    }

    void spawn_cylinder(double x, double y)
    {
        auto client = this->create_client<gazebo_msgs::srv::SpawnEntity>("/spawn_entity");
        if (!client->wait_for_service(std::chrono::seconds(10)))
        {
            RCLCPP_ERROR(this->get_logger(), "Spawn entity service is not available.");
            return;
        }

        auto request = std::make_shared<gazebo_msgs::srv::SpawnEntity::Request>();
        request->name = "cylinder";
        request->xml = R"(
            <sdf version='1.6'>
                <model name='cylinder'>
                    <pose>0 0 0.25 0 0 0</pose>
                    <link name='link'>
                        <inertial>
                            <mass>1.0</mass>
                            <inertia>
                                <ixx>1.0</ixx>
                                <iyy>1.0</iyy>
                                <izz>1.0</izz>
                            </inertia>
                        </inertial>
                        <collision name='collision'>
                            <geometry>
                                <cylinder>
                                    <radius>0.15</radius>
                                    <length>0.5</length>
                                </cylinder>
                            </geometry>
                        </collision>
                        <visual name='visual'>
                            <geometry>
                                <cylinder>
                                    <radius>0.15</radius>
                                    <length>0.5</length>
                                </cylinder>
                            </geometry>
                            <material>
                                <ambient>1 0 0 1</ambient>
                            </material>
                        </visual>
                    </link>
                </model>
            </sdf>
        )";
        request->initial_pose.position.x = x;
        request->initial_pose.position.y = y;
        request->initial_pose.position.z = 0.0;
        request->reference_frame = "world";

        auto future = client->async_send_request(request);
        rclcpp::spin_until_future_complete(this->get_node_base_interface(), future);
        if (future.valid() && future.get()->success)
        {
            RCLCPP_INFO(this->get_logger(), "Successfully spawned cylinder at (%f, %f).", x, y);
        }
        else
        {
            RCLCPP_ERROR(this->get_logger(), "Failed to spawn cylinder.");
        }
    }

  void generate_waypoints_around_cylinder(float x, float y, float yaw)
    {
        waypoints_.clear();
        double radius = 0.5;  // Distance to maintain from cylinder

        for (double angle = 0; angle < 2 * M_PI; angle += M_PI / 2) {
            geometry_msgs::msg::Pose waypoint;
            waypoint.position.x = x + radius * cos(angle);
            waypoint.position.y = y + radius * sin(angle);
            waypoint.orientation.w = 1.0;  // Neutral orientation
            waypoints_.push_back(waypoint);
        }

        waypoint_index_ = 0;
        deviation_reached_ = false;
        execute_waypoint_navigation();
    }

 void execute_waypoint_navigation()
{
    if (waypoint_index_ < waypoints_.size()) {
        // Set goal to next waypoint around the cylinder
        set_goal(waypoints_[waypoint_index_].position.x, waypoints_[waypoint_index_].position.y);
        waypoint_index_++;
    } else {
        // After completing all waypoints around the cylinder, return to the deviation point
        set_goal(deviation_return_pose_.position.x, deviation_return_pose_.position.y, 0.3);  // threshold of 0.3 meters
        deviation_reached_ = false;  // Set false when starting to return to deviation point
    }
}

 void mark_goal_on_map(double goal_x, double goal_y)
{
    int goal_pixel_x = static_cast<int>((goal_x - map_origin_.first) / map_resolution_) - room_roi_.x;
    int goal_pixel_y = static_cast<int>((-goal_y - map_origin_.second) / map_resolution_) - room_roi_.y;

    if (goal_pixel_x >= 0 && goal_pixel_x < ground_truth_map_cropped_.cols && goal_pixel_y >= 0 && goal_pixel_y < ground_truth_map_cropped_.rows) {
        cv::circle(ground_truth_map_cropped_, cv::Point(goal_pixel_x, goal_pixel_y), 5, cv::Scalar(255, 0, 255), -1);  // Pink color for Point B
    }
}
};


int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<CylinderDetectionNode>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}