#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/image.hpp>
#include <sensor_msgs/msg/laser_scan.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <geometry_msgs/msg/point.hpp>
#include <visualization_msgs/msg/marker.hpp>
#include <cv_bridge/cv_bridge.h>
#include <opencv2/opencv.hpp>
#include <image_transport/image_transport.hpp>
#include <cmath>
#include <unordered_map>
#include <chrono> 
#include <tf2/utils.h>
#include <tf2/LinearMath/Quaternion.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <tf2_ros/transform_listener.h>
#include <gazebo_msgs/srv/spawn_entity.hpp> // Service definition for spawning entities in Gazebo
#include <geometry_msgs/msg/pose.hpp>
using namespace std::chrono_literals;

// Custom hash function for std::pair<float, float>
struct pair_hash {
    template <class T1, class T2>
    std::size_t operator()(const std::pair<T1, T2>& p) const {
        auto hash1 = std::hash<T1>{}(p.first);
        auto hash2 = std::hash<T2>{}(p.second);
        return hash1 ^ (hash2 << 1); // Combine the two hash values
    }
};

class ColorObjectDetector : public rclcpp::Node {
public:
    ColorObjectDetector() : Node("color_object_detector") {
        // Subscriber to the image topic
        image_sub_ = this->create_subscription<sensor_msgs::msg::Image>(
            "/camera/image_raw", 10,
            std::bind(&ColorObjectDetector::imageCallback, this, std::placeholders::_1)
        );

        // Subscriber to the odometry topic
        odom_sub_ = this->create_subscription<nav_msgs::msg::Odometry>(
            "/odom", 10,
            std::bind(&ColorObjectDetector::odomCallback, this, std::placeholders::_1)
        );

        // Subscriber to the laser scan topic
        laser_scan_sub_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
            "/scan", 10,
            std::bind(&ColorObjectDetector::laserScanCallback, this, std::placeholders::_1)
        );

        // Publisher to the /waypoints topic
        waypoint_pub_ = this->create_publisher<geometry_msgs::msg::Point>("/waypoints_fire", 10);
spawn_client_ = this->create_client<gazebo_msgs::srv::SpawnEntity>("/spawn_entity");

// Wait for the service to become available
while (!spawn_client_->wait_for_service(1s)) {
    RCLCPP_INFO(this->get_logger(), "Waiting for /spawn_entity service to become available...");
}

        // Publisher for RViz markers
        marker_pub_ = this->create_publisher<visualization_msgs::msg::Marker>("/waypoint_markers", 10);

        RCLCPP_INFO(this->get_logger(), "Color Object Detector Node Started");
    }

void spawnRedCylinder() {
    // Prepare the request for spawning the cylinder
    auto request = std::make_shared<gazebo_msgs::srv::SpawnEntity::Request>();
    request->name = "red_cylinder";
    request->xml = R"(
        <sdf version="1.6">
          <model name="red_cylinder">
            <pose>2 2 0.5 0 0 0</pose> <!-- Height set at 0.5 to place it at ground level -->
            <link name="link">
              <pose>0 0 0.5 0 0 0</pose> <!-- Centered at half the height -->
              <collision name="collision">
                <geometry>
                  <cylinder>
                    <radius>0.25</radius> <!-- 50cm diameter means 0.25m radius -->
                    <length>1.0</length> <!-- 1m height -->
                  </cylinder>
                </geometry>
              </collision>
              <visual name="visual">
                <geometry>
                  <cylinder>
                    <radius>0.25</radius>
                    <length>1.0</length>
                  </cylinder>
                </geometry>
                <material>
                  <ambient>1 0 0 1</ambient> <!-- Red color -->
                  <diffuse>1 0 0 1</diffuse>
                </material>
              </visual>
            </link>
          </model>
        </sdf>
    )";
    request->initial_pose.position.x = 0.0;
    request->initial_pose.position.y = 0.0;
    request->initial_pose.position.z = 0.0; // Position on the ground
    request->initial_pose.orientation.w = 1.0;

    // Send the request and wait for the result
    auto result = spawn_client_->async_send_request(request);

    // Use `this->get_node_base_interface()` to safely access the node instance for spinning
    if (rclcpp::spin_until_future_complete(this->get_node_base_interface(), result) ==
        rclcpp::FutureReturnCode::SUCCESS) {
        RCLCPP_INFO(this->get_logger(), "Red cylinder spawned successfully.");
    } else {
        RCLCPP_ERROR(this->get_logger(), "Failed to spawn the red cylinder.");
    }
}
private:
    void imageCallback(const sensor_msgs::msg::Image::SharedPtr msg) {
        // Convert ROS image message to OpenCV image
        cv_bridge::CvImagePtr cv_ptr;
        try {
            cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
        } catch (cv_bridge::Exception& e) {
            RCLCPP_ERROR(this->get_logger(), "cv_bridge exception: %s", e.what());
            return;
        }

        cv::Mat img_bgr = cv_ptr->image;

        // Convert BGR to HSV
        cv::Mat img_hsv;
        cv::cvtColor(img_bgr, img_hsv, cv::COLOR_BGR2HSV);

        // Define HSV range for the target color (e.g., RGB[247, 55, 24])
        cv::Scalar lower_hsv(0, 200, 200);
        cv::Scalar upper_hsv(10, 255, 255);

        // Create a mask for the color
        cv::Mat mask;
        cv::inRange(img_hsv, lower_hsv, upper_hsv, mask);

        // Find contours in the mask
        std::vector<std::vector<cv::Point>> contours;
        cv::findContours(mask, contours, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);

        // Process each detected object
        for (const auto& contour : contours) {
            if (cv::contourArea(contour) > 500) { // Ignore small objects
                cv::Rect bounding_box = cv::boundingRect(contour);
                cv::rectangle(img_bgr, bounding_box, cv::Scalar(0, 255, 0), 2); // Green outline

                // Calculate object's position
                auto [obj_x, obj_y] = calculateObjectPosition(bounding_box);

                // Increment the detection count for this object position
                auto key = std::make_pair(round(obj_x * 10) / 10.0, round(obj_y * 10) / 10.0); // Round to avoid precision issues
                detection_count_[key]++;

                // Publish if object detected at least twice and is a new waypoint
                if (detection_count_[key] >= 3 && isNewWaypoint(obj_x, obj_y)) {
                    RCLCPP_INFO(this->get_logger(), "Publishing waypoint at (x, y): (%.2f, %.2f)", obj_x, obj_y);
                    publishWaypoint(obj_x, obj_y);
                    waypoints_.emplace_back(obj_x, obj_y); // Store the new waypoint
                }
            }
        }

        // Display the result
        cv::imshow("Detected Objects", img_bgr);
        cv::waitKey(1);
    }

    std::pair<float, float> calculateObjectPosition(const cv::Rect& bounding_box) {
        // Using the center of the bounding box and laser scan data to estimate the position
        float obj_x = current_x_;  // Default to robot's position if no scan data
        float obj_y = current_y_;

        if (!last_scan_.ranges.empty()) {
            int center_idx = bounding_box.x + bounding_box.width / 2;

            // Calculate the object's angle relative to the robot's orientation
            float angle = last_scan_.angle_min + center_idx * last_scan_.angle_increment;
            float distance = last_scan_.ranges[center_idx];

            // Calculate (x, y) relative to the robot's odometry
            obj_x = current_x_ + distance * std::cos(current_yaw_ + angle);
            obj_y = current_y_ + distance * std::sin(current_yaw_ + angle);
        }
        return {obj_x, obj_y};
    }

    bool isNewWaypoint(float x, float y) {
        // Check if the waypoint is at least 0.5m away from existing waypoints
        for (const auto& [wp_x, wp_y] : waypoints_) {
            float distance = std::sqrt(std::pow(x - wp_x, 2) + std::pow(y - wp_y, 2));
            if (distance < 0.7) {
                return false;
            }
        }
        return true;
    }

    

    void publishWaypoint(float x, float y) {
        // Publish as a Point message
        geometry_msgs::msg::Point waypoint;
        waypoint.x = x;
        waypoint.y = y;
        waypoint.z = 0.0;
        waypoint_pub_->publish(waypoint);

        // Publish as a Marker message for RViz visualization
        visualization_msgs::msg::Marker marker;
        marker.header.frame_id = "map"; // Adjust the frame ID as necessary
        marker.header.stamp = this->get_clock()->now();
        marker.ns = "waypoints";
        marker.id = waypoints_.size(); // Unique ID for each marker
        marker.type = visualization_msgs::msg::Marker::SPHERE; // Use SPHERE for a point marker
        marker.action = visualization_msgs::msg::Marker::ADD;
        marker.pose.position.x = x;
        marker.pose.position.y = y;
        marker.pose.position.z = 0.0;
        marker.pose.orientation.w = 1.0; // Neutral orientation
        marker.scale.x = 0.2; // Diameter of the sphere marker
        marker.scale.y = 0.2;
        marker.scale.z = 0.2;
        marker.color.r = 1.0; // Red color
        marker.color.g = 0.0;
        marker.color.b = 0.0;
        marker.color.a = 1.0; // Fully opaque
        marker_pub_->publish(marker);
    }

    void odomCallback(const nav_msgs::msg::Odometry::SharedPtr msg) {
        // Store the robot's current position and orientation
        current_x_ = msg->pose.pose.position.x;
        current_y_ = msg->pose.pose.position.y;
        current_yaw_ = tf2::getYaw(msg->pose.pose.orientation);
    }

    void laserScanCallback(const sensor_msgs::msg::LaserScan::SharedPtr msg) {
        // Store the latest laser scan data for object distance calculation
        last_scan_ = *msg;
    }

    rclcpp::Subscription<sensor_msgs::msg::Image>::SharedPtr image_sub_;
    rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odom_sub_;
    rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr laser_scan_sub_;
    rclcpp::Publisher<geometry_msgs::msg::Point>::SharedPtr waypoint_pub_;
    rclcpp::Publisher<visualization_msgs::msg::Marker>::SharedPtr marker_pub_;
    rclcpp::Client<gazebo_msgs::srv::SpawnEntity>::SharedPtr spawn_client_;


    sensor_msgs::msg::LaserScan last_scan_;
    float current_x_ = 0.0;
    float current_y_ = 0.0;
    float current_yaw_ = 0.0;

    std::vector<std::pair<float, float>> waypoints_; // To store unique waypoints
    std::unordered_map<std::pair<float, float>, int, pair_hash> detection_count_; // Count detections with custom hash
};

// Main function
int main(int argc, char** argv) {
    rclcpp::init(argc, argv);
    auto node = std::make_shared<ColorObjectDetector>();
    node->spawnRedCylinder();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}

