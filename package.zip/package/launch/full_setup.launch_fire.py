from launch import LaunchDescription
from launch.actions import ExecuteProcess, TimerAction
from launch_ros.actions import Node
import os

def generate_launch_description():

    ws_directory = '/home/student/ros2_ws'  


    turtlebot3_gazebo_process = ExecuteProcess(
        cmd=['ros2', 'launch', 'turtlebot3_gazebo', 'turtlebot3_world.launch.py'],
        cwd=ws_directory,
        output='screen'
    )

  
    cartographer_process = TimerAction(
        period=5.0,  
        actions=[
            ExecuteProcess(
                cmd=['ros2', 'launch', 'turtlebot3_cartographer', 'cartographer.launch.py', 'use_sim_time:=True'],
                cwd=ws_directory,
                output='screen'
            )
        ]
    )

    
    nav2_process = TimerAction(
    period=10.0,  # Additional delay for initialization
    actions=[
        ExecuteProcess(
            cmd=[
                'ros2', 'launch', 'turtlebot3_navigation2', 'navigation2.launch.py',
                'map:=/home/student/map_slam.yaml', 'use_sim_time:=True'
            ],
            cwd=ws_directory,
            output='screen'
        )
    ]
)

    
    set_initial_pose = TimerAction(
        period=12.0,  
        actions=[
            ExecuteProcess(
                cmd=[
                    'ros2', 'topic', 'pub', '/initialpose', 'geometry_msgs/PoseWithCovarianceStamped',
                    '{pose: {pose: {position: {x: 0.0, y: 0.0, z: 0.0}, orientation: {z: 0.0, w: 1.0}}}}'
                ],
                output='screen'
            )
        ]
    )

    
    cylinder_detection_node = TimerAction(
        period=15.0,  
        actions=[
            Node(
                package='robotics_studio_1',
                executable='sprint4fire',
                name='cylinder_detection_node',
                output='screen',
                parameters=[{'use_sim_time': True}]
            )
        ]
    )

    return LaunchDescription([
        turtlebot3_gazebo_process,
        cartographer_process,
        nav2_process,
        set_initial_pose,
        cylinder_detection_node
    ])
