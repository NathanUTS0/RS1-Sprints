var searchData=
[
  ['detected_5fcylinder_5f_34',['detected_cylinder_',['../classCylinderDetectionNode.html#a0d014486c9a141f5464725d0faf4d180',1,'CylinderDetectionNode']]]
];
